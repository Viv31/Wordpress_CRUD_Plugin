<!DOCTYPE html>
<html>
<head>
	<title>Custom Plugin</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/plugin_style.css">
<style type="text/css">
	body{
	background-image: url("img/bg.jpg");
}
</style>

</head>
<body>



